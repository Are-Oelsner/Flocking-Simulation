Name: Are Oelsner
README File for my BallSimulation repository

Hi Jory,

If you could check out my code and in particular the checkIntersection code in my simulation.java file I'd appreciate it.

Thanks!

Are

Contains:

Ball.java
BallSimulation.java
Collision.java
        Takes initial velocity and object normal as input and returns
        new velocity
GUI.java
Input.sim
Normalcalc.java
        Program to help calculate normal Vectors for Obstacles file
Obstacle.obst
        File for Obstacle construction
Obstacles.java
        Constructs Polygons from file
        Working on Drawing Obstacles to JFrame
Simulator.java
Vector.java

11/27/16
Work on finding intersection between two lines
        Object.java
        Simulator.java >> update
        Collision.java

